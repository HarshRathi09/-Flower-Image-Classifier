import numpy as np
import torch
from torch import nn
from torch import tensor
from torch import optim
import torch.nn.functional as f
from torch.autograd import Variable
import torchvision.models as models
from torchvision import datasets, transforms
from collections import OrderedDict
import json
from PIL import Image
import PIL

arch = {"vgg16":25088,
        "densenet121":1024
        }

def load_data(data  = "./flowers" ):
 
    data_dir = data
    train_dir = data_dir + '/train'
    valid_dir = data_dir + '/valid'
    test_dir = data_dir + '/test'

    train_transforms = transforms.Compose([transforms.RandomRotation(50),
                                           transforms.RandomResizedCrop(224),
                                           transforms.RandomHorizontalFlip(),
                                           transforms.ToTensor(),
                                           transforms.Normalize([0.485, 0.456, 0.406],
                                                                [0.229, 0.224, 0.225])])

    test_transforms = transforms.Compose([transforms.Resize(256),
                                          transforms.CenterCrop(224),
                                          transforms.ToTensor(),
                                          transforms.Normalize([0.485, 0.456, 0.406],
                                                               [0.229, 0.224, 0.225])])

    validation_transforms = transforms.Compose([transforms.Resize(256),                             transforms.CenterCrop(224),transforms.ToTensor(),transforms.Normalize([0.485, 0.456, 0.406],[0.229, 0.224, 0.225])])

    train_data = datasets.ImageFolder(train_dir, transform=train_transforms)
    validation_data = datasets.ImageFolder(valid_dir, transform=validation_transforms)
    test_data = datasets.ImageFolder(test_dir ,transform = test_transforms)
 
    train_loader = torch.utils.data.DataLoader(train_data, batch_size=64, shuffle=True)
    valid_loader = torch.utils.data.DataLoader(validation_data, batch_size =32,shuffle = True)
    test_loader = torch.utils.data.DataLoader(test_data, batch_size = 20, shuffle = True)

    return  train_loader, valid_loader, test_loader

def neural_network(structure='densenet121', dropout=0.5, hidden_layer=120, lr=0.001, power='gpu'):
    train_loader, valid_loader, test_loader = load_data()

    if structure == 'vgg16':
        model = models.vgg16(pretrained=True)
        arch = {'structure': 25088,
                'classifier': nn.Sequential(OrderedDict([
                    ('dropout', nn.Dropout(dropout)),
                    ('fc1', nn.Linear(25088, hidden_layer)),
                    ('relu1', nn.ReLU()),
                    ('fc2', nn.Linear(hidden_layer,len(train_loader.dataset.class_to_idx))),
                    ('output', nn.LogSoftmax(dim=1))
                ]))}
    elif structure == 'densenet121':
        model = models.densenet121(pretrained=True)
        arch = {'structure': 1024,
                'classifier': nn.Sequential(OrderedDict([
                    ('dropout', nn.Dropout(dropout)),
                    ('fc1', nn.Linear(1024, hidden_layer)),
                    ('relu1', nn.ReLU()),
                    ('fc2', nn.Linear(hidden_layer,len(train_loader.dataset.class_to_idx))),
                    ('output', nn.LogSoftmax(dim=1))
                ]))}
 
    else:
        print("Please enter a valid model.Did you mean vgg16 or densenet121?".format(structure))
        exit()

    model.classifier = arch['classifier']
    criterion = nn.NLLLoss()
    optimizer = optim.Adam(model.classifier.parameters(), lr)

    if torch.cuda.is_available() and power == 'gpu':
        model.cuda()

    return model, criterion, optimizer

def train_network(model, criterion, optimizer, epochs=10, print_every=20, train_loader=None, valid_loader=None, power='gpu'):
    steps = 0
    running_loss = 0

    print("Training is starting")
    for e in range(epochs):
        running_loss = 0
        for ii, (inputs,labels) in enumerate(train_loader):
            steps += 1
            if torch.cuda.is_available() and power == 'gpu':
                inputs,labels = inputs.to('cuda'), labels.to('cuda')

            optimizer.zero_grad()

            outputs = model.forward(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            running_loss += loss.item()

            if steps % print_every == 0:
                model.eval()
                loss = 0
                accuracy = 0

                for i,(inputs,labels) in enumerate(valid_loader):
                    optimizer.zero_grad()
                    if torch.cuda.is_available():
                        inputs,labels = inputs.to('cuda:0'), labels.to('cuda:0')
                        model.to('cuda:0')

                    with torch.no_grad():
                        outputs = model

def save_checkpoint(model,train_loader, path='checkpoint.pth', hidden_layer=120, dropout=0.5, lr=0.001, epochs=10):
    model.class_to_idx = train_loader.dataset.class_to_idx
    model.cpu()
    checkpoint = {'structure': 'densenet121',
                  'hidden_layer': hidden_layer,
                  'dropout': dropout,
                  'lr': lr,
                  'epochs': epochs,
                  'state_dict': model.state_dict(),
                  'class_to_idx': model.class_to_idx
                 }
    torch.save(checkpoint, path)

def load_checkpoint(path='checkpoint.pth'):

    checkpoint = torch.load(path)
    structure = checkpoint['structure']
    hidden_layer = checkpoint['hidden_layer']
    dropout = checkpoint['dropout']
    lr=checkpoint['lr']

    model = neural_network(structure,dropout,hidden_layer,lr)

    model.class_to_idx = checkpoint['class_to_idx']
    model.load_state_dict(checkpoint['state_dict'])


def predict(image_path, model, topk=5,power='gpu'):

    if torch.cuda.is_available() and power=='gpu':
        model.to('cuda:0')

    image_torch = process_image(image_path)
    image_torch = img_torch.unsqueeze_(0)
    image_torch = img_torch.float()

    if power == 'gpu' and torch.cuda.is_available():
        with torch.no_grad():
            output = model.forward(image_torch.cuda())
    else:
        with torch.no_grad():
            output=model.forward(image_torch)

    probability = f.softmax(output.data,dim=1)

    return probability.topk(topk)