import argparse
import functions
from torchvision import datasets,transforms

def load_data(data = "./flowers" ):
    
    data_dir = data
    train_dir = data_dir + '/train'
    valid_dir = data_dir + '/valid'
    test_dir = data_dir + '/test'

    
import argparse

# Define the command line arguments
parser = argparse.ArgumentParser(description='Train a neural network to classify images')

parser.add_argument('data_directory', nargs='*', action='store', default='./flowers/')
parser.add_argument('--save_directory', dest='save_directory', action='store', default='./checkpoint.pth')
parser.add_argument('--learning_rate', dest='learning_rate', action='store', default=0.001, type=float)
parser.add_argument('--architecture', dest='architecture', action='store', default='vgg16', type=str)
parser.add_argument('--dropout', dest='dropout', action='store', default=0.5, type=float)
parser.add_argument('--hidden_units', dest='hidden_units', action='store', default=120, type=int)
parser.add_argument('--epochs', dest='epochs', action='store', default=1, type=int)
parser.add_argument('--use_gpu', dest='use_gpu', action='store_true', default=False)
parser.add_argument('--input_image', dest='input_image', action='store', default='image.jpg')

# Parse the command line arguments
args = parser.parse_args()

# Assign variables from the parsed arguments
data_dir = args.data_directory
save_dir = args.save_directory
learning_rate = args.learning_rate
arch = args.architecture
dropout = args.dropout
hidden_units = args.hidden_units
epochs = args.epochs
use_gpu = args.use_gpu


# Load the data
train_loader, valid_loader, test_loader=functions.load_data(data_dir)

train_data = ('./flowers/train')
# Build the model
model, optimizer, criterion = functions.neural_network(arch, dropout, hidden_units, learning_rate, power='gpu')

# Train the network
functions.train_network(model, optimizer, criterion, epochs, 2, train_loader, valid_loader, power='gpu')

import torch
import futils

# Set the path where you want to save the checkpoint
path = './checkpoint.pth'
structure = 'densenet121'
hidden_layer = 256
dropout = 0.3
lr = 0.0001
epochs = 10

def train_and_save(model, criterion, optimizer, train_loader, valid_loader, save_path):
    # train the model
    epochs = 10
    print_every = 40
    steps = 0
    model.to(device)

    for epoch in range(epochs):
        running_loss = 0
        for inputs, labels in train_loader:
            steps += 1
            inputs, labels = inputs.to(device), labels.to(device)
            optimizer.zero_grad()
            outputs = model.forward(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            running_loss += loss.item()

            if steps % print_every == 0:
                model.eval()
                with torch.no_grad():
                    valid_loss, accuracy = validation(model, criterion, valid_loader)

                print("Epoch: {}/{}... ".format(epoch + 1, epochs),
                      "Training Loss: {:.3f}".format(running_loss / print_every),
                      "Validation Loss: {:.3f}".format(valid_loss / len(valid_loader)),
                      "Validation Accuracy: {:.3f}".format(accuracy / len(valid_loader)))

                running_loss = 0
                model.train()

    # Save the checkpoint
    save_checkpoint(model, train_loader, path=save_path)

    return model

print("The Model is trained")