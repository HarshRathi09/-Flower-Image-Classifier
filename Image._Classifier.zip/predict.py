import argparse
import json
import numpy as np
import torch
from PIL import Image
from torch.autograd import Variable
import functions

parser = argparse.ArgumentParser(description='Make predictions on an input image using a trained neural network')

parser.add_argument('--image_path', dest='image_path', action='store', default='/home/workspace/flowers/test/1/image_06752.jpg', type=str,help='The path to the input image file')
parser.add_argument('--checkpoint_path', dest='checkpoint_path', action='store', default='/home/workspace/ImageClassifier/checkpoint.pth', type=str,help='The path to the saved checkpoint file')
parser.add_argument('--top_k', dest='top_k',action='store',default=5,type=int,help='The number of top predictions to return')
parser.add_argument('--category_names', dest='category_names', action='store', default='cat_to_name.json',type=str,help='The file containing the mapping of category numbers to names')
parser.add_argument('--gpu', dest='gpu', action='store', default='gpu', type=str,help='Whether to use GPU for prediction or not')

args = parser.parse_args()

# Assign variables from the parsed arguments
image_path = args.image_path
checkpoint_path = args.checkpoint_path
top_k = args.top_k
category_names = args.category_names
gpu = args.gpu


# Load Data
train_loader, test_loader, valid_loader = functions.load_data()

model = functions.load_checkpoint(checkpoint_path)

# Load Label Mapping
with open(args.category_names, 'r') as f:
    cat_to_name = json.load(f)

# Predict Image
image = Image.open(image_path)
probs, indices = predict(image_path, model, topk)

# Convert the indices to class labels using the class_to_idx dictionary
idx_to_class = {val: key for key, val in model.class_to_idx.items()}
classes = [idx_to_class[idx] for idx in indices[0]]

print('Probabilities:', probs)
print('Classes:', classes)


# Print Results
print("Top {} predictions for image '{}':".format(top_k,image_path))
for i in range(top_k):
    print("{}: {:.3f}".format(cat_to_name[classes[i]], probs[i]))
